﻿' (c) Copyright Microsoft Corporation.
' This source is subject to the Microsoft Public License (Ms-PL).
' Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
' All other rights reserved.

Namespace Samples

    Partial Public Class TiltEffectSample
        Inherits PhoneApplicationPage
        Public Sub New()
            InitializeComponent()
        End Sub
    End Class
End Namespace
