﻿' (c) Copyright Microsoft Corporation.
' This source is subject to the Microsoft Public License (Ms-PL).
' Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
' All other rights reserved.

Namespace Data
    Public Class Tuple(Of T, U)
        Public Property Item1 As T

        Public Property Item2 As U
    End Class
End Namespace

